package com.example.aggressivity;

public enum AggressivityState {
    PASSIVE,
    NATURAL,
    FULLY_AGGRESSIVE,
    NORMAL
}
