package com.example.aggressivity.mixin;

import com.example.aggressivity.MobAggressivityComponent;
import com.example.aggressivity.AggressivityState;
import net.minecraft.entity.LivingEntity;
import net.minecraft.nbt.NbtCompound;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.At.Shift;

import java.util.UUID;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {

    // Inject into writeCustomDataToNbt to save our state
    @Inject(method = "writeCustomDataToNbt", at = @At("TAIL"))
    private void onWriteCustomDataToNbt(NbtCompound tag, CallbackInfo ci) {
        LivingEntity self = (LivingEntity)(Object)this;
        MobAggressivityComponent comp = MobAggressivityComponent.get(self);
        comp.writeToNbt(tag);
    }

    // Inject into readCustomDataFromNbt to load our state
    @Inject(method = "readCustomDataFromNbt", at = @At("TAIL"))
    private void onReadCustomDataFromNbt(NbtCompound tag, CallbackInfo ci) {
        LivingEntity self = (LivingEntity)(Object)this;
        MobAggressivityComponent comp = MobAggressivityComponent.get(self);
        comp.readFromNbt(tag);
    }

    /**
     * Redirect setTarget calls to prevent setting target when PASSIVE, and allow NATURAL only for revenge/attacker.
     * We assume an accessible method setTarget(LivingEntity). This is a best-effort approach and might need mapping adjustments.
     */
    @Redirect(method = "setTarget", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;setTarget(Lnet/minecraft/entity/LivingEntity;)V"))
    private void redirectSetTarget(LivingEntity instance, LivingEntity target) {
        MobAggressivityComponent comp = MobAggressivityComponent.get(instance);
        AggressivityState state = comp.getState();

        if (state == AggressivityState.PASSIVE) {
            // cancel setting target
            return;
        } else if (state == AggressivityState.NATURAL) {
            // NATURAL: allow if target is attacker/revenge target. Best-effort: allow if target recently damaged the entity
            try {
                java.lang.reflect.Method getRecentDamageSource = instance.getClass().getMethod("getRecentDamageSource");
                Object src = getRecentDamageSource.invoke(instance);
                // Without robust method, fall back to allowing null checks; conservative approach: deny unless target is null (clearing)
            } catch (Exception ignored) {
                // mapping limitations — conservative: if setting non-null target, disallow unless it's an instance of PlayerEntity (heuristic)
                if (target != null && !(target instanceof net.minecraft.entity.player.PlayerEntity)) {
                    return;
                }
            }
        }
        // otherwise, allow default behavior
        try {
            java.lang.reflect.Method setTarget = instance.getClass().getMethod("setTarget", LivingEntity.class);
            setTarget.invoke(instance, target);
        } catch (Exception ignored) {}
    }
}
