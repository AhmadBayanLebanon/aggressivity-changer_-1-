package com.example.aggressivity;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Box;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class MobAggressivityComponent {
    private static final Map<UUID, MobAggressivityComponent> MAP = new ConcurrentHashMap<>();

    private AggressivityState state = AggressivityState.NORMAL;
    private final LivingEntity entity;

    private MobAggressivityComponent(LivingEntity entity) {
        this.entity = entity;
    }

    public static MobAggressivityComponent get(LivingEntity entity) {
        UUID id = entity.getUuid();
        return MAP.computeIfAbsent(id, k -> new MobAggressivityComponent(entity));
    }

    public AggressivityState getState() {
        return state;
    }

    public void setState(AggressivityState s) {
        this.state = s;
    }

    public void cycleState() {
        switch (state) {
            case NORMAL -> state = AggressivityState.PASSIVE;
            case PASSIVE -> state = AggressivityState.NATURAL;
            case NATURAL -> state = AggressivityState.FULLY_AGGRESSIVE;
            case FULLY_AGGRESSIVE -> state = AggressivityState.NORMAL;
        }
        // If passive or natural, clear current target to avoid lingering aggression
        try {
            java.lang.reflect.Method clearTarget = entity.getClass().getMethod("setTarget", LivingEntity.class);
            if (state == AggressivityState.PASSIVE || state == AggressivityState.NATURAL) {
                clearTarget.invoke(entity, new Object[] { null });
            }
        } catch (Exception ignored) {}
    }

    public void readFromNbt(NbtCompound tag) {
        if (tag == null) return;
        if (tag.contains("AggressivityChanger_state")) {
            try {
                this.state = AggressivityState.valueOf(tag.getString("AggressivityChanger_state"));
            } catch (Exception ignored) {}
        }
    }

    public void writeToNbt(NbtCompound tag) {
        if (tag == null) return;
        tag.putString("AggressivityChanger_state", state.name());
    }

    /**
     * Apply a simple aggressive behavior: if the mob has no target, find the nearest living target (players or other living entities)
     * within a search box and set as target. This method uses safe APIs but is intentionally basic.
     */
    public void applyAggressiveBehavior() {
        if (!(entity.world instanceof ServerWorld)) return;
        ServerWorld world = (ServerWorld) entity.world;

        // If entity already has a target, skip
        try {
            java.lang.reflect.Method m = entity.getClass().getMethod("getTarget");
            Object t = m.invoke(entity);
            if (t != null) return;
        } catch (Exception ignored) {}

        Box box = new Box(entity.getX()-16, entity.getY()-4, entity.getZ()-16, entity.getX()+16, entity.getY()+4, entity.getZ()+16);
        List<LivingEntity> list = world.getEntitiesByClass(LivingEntity.class, box, e -> e != entity);

        if (list.isEmpty()) return;

        Optional<LivingEntity> playerOpt = list.stream().filter(e -> e instanceof PlayerEntity).findFirst();
        LivingEntity target = playerOpt.orElse(list.get(0));

        try {
            java.lang.reflect.Method setTarget = entity.getClass().getMethod("setTarget", LivingEntity.class);
            setTarget.invoke(entity, target);
        } catch (Exception e) {
            // ignore
        }
    }
}
