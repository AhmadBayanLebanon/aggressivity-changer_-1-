package com.example.aggressivity;

import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.util.ActionResult;

public class AggressivityChangerItem extends Item {
    public AggressivityChangerItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnEntity(ItemUsageContext context) {
        if (context.getWorld().isClient) return ActionResult.PASS;
        if (!(context.getEntity() instanceof LivingEntity)) return ActionResult.PASS;

        LivingEntity mob = (LivingEntity) context.getEntity();
        MobAggressivityComponent comp = MobAggressivityComponent.get(mob);
        comp.cycleState();
        return ActionResult.SUCCESS;
    }
}
